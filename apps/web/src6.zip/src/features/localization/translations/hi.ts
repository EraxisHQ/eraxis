export const hi = {
  welcome: "एराक्सिस में आपका स्वागत है",

  dashboard: "डैशबोर्ड",
  applications: "एप्लिकेशन",
  administration: "प्रशासन",
  settings: "सेटिंग्स",

  users: "उपयोगकर्ता",
  tenants: "किरायेदार",

  systemStatus: "सिस्टम स्थिति",
  recentActivity: "हाल की गतिविधि",

  brands: "ब्रांड",

  brandFoundation:
  "ब्रांड मॉड्यूल",
  
  products:
  "उत्पाद",

productFoundation:
  "उत्पाद मॉड्यूल",

categories:
  "श्रेणियाँ",

categoryFoundation:
  "श्रेणी मॉड्यूल",

inventory:
  "इन्वेंटरी",

inventoryFoundation:
  "इन्वेंटरी मॉड्यूल",

customers:
  "ग्राहक",

customerFoundation:
  "ग्राहक मॉड्यूल",

orders:
  "ऑर्डर",

orderFoundation:
  "ऑर्डर मॉड्यूल",

pricing:
  "मूल्य निर्धारण",

pricingFoundation:
  "मूल्य निर्धारण मॉड्यूल",

  productVariants:
    "उत्पाद प्रकार",

  productVariantFoundation:
    "उत्पाद प्रकार आधार",

  customerAddresses:
    "ग्राहक पते",

  customerAddressFoundation:
    "ग्राहक पता मॉड्यूल",

  orderLifecycle:
    "ऑर्डर जीवनचक्र",

  orderLifecycleFoundation:
    "ऑर्डर जीवनचक्र मॉड्यूल",

  orderItems:
    "ऑर्डर आइटम",

  orderItemFoundation:
    "ऑर्डर आइटम मॉड्यूल",

  invoices:
    "चालान",

  invoiceFoundation:
    "चालान मॉड्यूल",

  payments:
    "भुगतान",

  paymentFoundation:
    "भुगतान मॉड्यूल",

  taxes:
    "कर",

  taxFoundation:
    "कर मॉड्यूल",

  discounts:
    "छूट",

  discountFoundation:
    "छूट मॉड्यूल",

  shipping:
    "शिपिंग",

  shippingFoundation:
    "शिपिंग मॉड्यूल",
};