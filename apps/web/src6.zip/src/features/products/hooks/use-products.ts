import {
  useEffect,
  useState,
} from "react";

import type {
  Product,
} from "../types/product";

import {
  productService,
} from "../services/product-service";

export function useProducts() {
  const [products, setProducts] =
    useState<Product[]>([]);

  useEffect(() => {
    async function load() {
      const data =
        await productService.findAll();

      setProducts(data);
    }

    load();
  }, []);

  return products;
}
