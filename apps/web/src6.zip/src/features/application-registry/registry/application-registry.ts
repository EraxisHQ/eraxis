/**
 * =====================================
 * Eraxis
 * Module: Application Registry
 *
 * Purpose:
 * Central application registry.
 *
 * Milestone:
 * M001-02-02
 * =====================================
 */

import type {
  Application,
} from "../types/application";

/**
 * Runtime registry.
 *
 * Future plugins:
 * Commerce
 * HRMS
 * Fleet
 * Inventory
 */

export const APPLICATION_REGISTRY:
  Application[] = [
    {
      id: "core",

      code: "CORE",

      name: "Core Platform",

      route: "/dashboard",

      enabled: true,

      featureFlag: "core",
    },

    {
      id: "commerce",

      code: "COMMERCE",

      name: "Commerce",

      route: "/commerce",

      enabled: true,

      featureFlag: "commerce",
    },
  ];
