export interface StorageProvider {

  get<T>(
    key: string
  ): Promise<T | null>;

  set<T>(
    key: string,
    value: T
  ): Promise<void>;

  delete(
    key: string
  ): Promise<void>;
}
